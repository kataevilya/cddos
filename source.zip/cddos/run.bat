qemu-system-x86_64 -fda CD-DOS.IMG
pause