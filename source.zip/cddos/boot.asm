; CD-DOS Bootloader
; Build: nasm -f bin boot.asm -o boot.bin

ORG 0x7C00
USE16

start:
    ; Настройка сегментов
    xor ax, ax
    mov ds, ax
    mov es, ax
    mov ss, ax
    mov sp, 0x7C00
    
    mov si, msg_loading
    call print
    
    ; Загружаем ядро (сектора 2-16, всего 15 секторов)
    mov ax, 0x1000      ; ES:BX = 0x1000:0x0000
    mov es, ax
    xor bx, bx
    
    mov ah, 0x02        ; Функция чтения
    mov al, 15          ; 15 секторов
    mov ch, 0           ; Цилиндр 0
    mov cl, 2           ; Начальный сектор 2
    mov dh, 0           ; Головка 0
    mov dl, 0x00        ; Диск A:
    int 0x13
    jc error
    
    ; Проверяем, что ядро загружено (первый байт должен быть 0xE9 или 0xEB - JMP)
    mov ax, 0x1000
    mov ds, ax
    mov al, [0x0000]
    cmp al, 0xE9
    je ok
    cmp al, 0xEB
    je ok
    cmp al, 0xEA
    je ok
    
    mov si, msg_no_kernel
    call print
    jmp hang
    
ok:
    mov si, msg_ok
    call print
    
    ; Переход на ядро
    mov ax, 0x1000
    mov ds, ax
    mov es, ax
    jmp 0x1000:0x0000

error:
    mov si, msg_error
    call print
    jmp hang

print:
    lodsb
    cmp al, 0
    je done
    mov ah, 0x0E
    int 0x10
    jmp print
done:
    ret

hang:
    mov si, msg_hang
    call print
    xor ax, ax
    int 0x16          ; Ждём клавишу
    int 0x19          ; Перезагрузка

msg_loading    db 'CD-DOS Bootloader v1.0', 13, 10, 'Loading kernel... ', 0
msg_ok         db 'OK', 13, 10, 0
msg_error      db 'FAILED!', 13, 10, 0
msg_no_kernel  db 'No kernel found!', 13, 10, 0
msg_hang       db 'Press any key to reboot...', 0

times 510 - ($ - $$) db 0
dw 0xAA55