@echo off
chcp 65001 >nul
echo === Building CD-DOS ===

echo [1/3] Compiling bootloader...
nasm -f bin boot.asm -o boot.bin
if %errorlevel% neq 0 (
    echo Ошибка: NASM не найден или ошибка компиляции
    pause
    exit /b 1
)

echo [2/3] Compiling kernel...
nasm -f bin kernel.asm -o kernel.bin
if %errorlevel% neq 0 (
    echo Ошибка компиляции ядра
    pause
    exit /b 1
)

echo [3/3] Creating floppy image...

REM Создаём загрузочный образ с помощью copy /b
copy /y boot.bin CD-DOS.IMG > nul

REM Добавляем ядро
copy /b CD-DOS.IMG + kernel.bin CD-DOS.IMG > nul

REM Проверяем размер файла
for %%A in (CD-DOS.IMG) do set size=%%~zA

echo Создан файл: CD-DOS.IMG
echo Размер: %size% байт

if %size% LSS 10000 (
    echo ВНИМАНИЕ: Файл слишком маленький!
    echo Возможно, произошла ошибка при сборке.
    pause
    exit /b 1
)

echo.
echo ========================================
echo УСПЕШНО! Создан CD-DOS.IMG
echo.
echo Для запуска выполните:
echo qemu-system-x86_64 -fda CD-DOS.IMG
echo ========================================
echo.
pause