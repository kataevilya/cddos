@echo off
chcp 65001 >nul
echo ========================================
echo   Building CD-DOS with KERNEL.SYS
echo ========================================
echo.

echo [1/5] Compiling bootloader...
nasm -f bin boot.asm -o boot.bin
if errorlevel 1 goto error

echo [2/5] Compiling kernel...
nasm -f bin kernel.asm -o kernel.bin
if errorlevel 1 goto error

echo [3/5] Renaming kernel to KERNEL.SYS...
copy kernel.bin KERNEL.SYS > nul

echo [4/5] Creating floppy image...
REM Создаём пустой образ 1.44MB через PowerShell
powershell -Command "$stream = [System.IO.File]::OpenWrite('CD-DOS.IMG'); $stream.SetLength(1474560); $stream.Close()"

REM Записываем bootloader в первый сектор
powershell -Command "$boot = [System.IO.File]::ReadAllBytes('boot.bin'); $fs = [System.IO.File]::OpenWrite('CD-DOS.IMG'); $fs.Write($boot, 0, $boot.Length); $fs.Close()"

REM Форматируем остальную часть как FAT12
echo [5/5] Adding KERNEL.SYS to disk image...
powershell -Command "
    # Открываем образ
    $fs = [System.IO.File]::Open('CD-DOS.IMG', [System.IO.FileMode]::Open, [System.IO.FileAccess]::Write)
    
    # Создаём простую FAT12 таблицу (заглушка)
    $bootSector = New-Object byte[] 512
    $fs.Seek(0, [System.IO.SeekOrigin]::Begin) | Out-Null
    $fs.Read($bootSector, 0, 512) | Out-Null
    
    # Пишем KERNEL.SYS начиная с сектора 33 (место для файлов)
    $kernel = [System.IO.File]::ReadAllBytes('KERNEL.SYS')
    $fs.Seek(33 * 512, [System.IO.SeekOrigin]::Begin) | Out-Null
    $fs.Write($kernel, 0, $kernel.Length) | Out-Null
    
    $fs.Close()
"

echo.
echo ========================================
echo   BUILD SUCCESSFUL!
echo ========================================
echo.
echo Созданы файлы:
echo   - KERNEL.SYS     (ядро системы)
echo   - CD-DOS.IMG     (образ дискеты с KERNEL.SYS)
echo.
echo Для запуска:
echo   qemu-system-x86_64 -fda CD-DOS.IMG
echo.
echo ========================================
goto end

:error
echo.
echo ОШИБКА! Убедитесь, что NASM установлен.
echo.
pause

:end
pause