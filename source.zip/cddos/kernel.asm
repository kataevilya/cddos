; CD-DOS Kernel v2.0 - Full Version
; Build: nasm -f bin kernel.asm -o kernel.bin

ORG 0x0000
USE16

start:
    jmp init

; ========== Текстовые сообщения ==========
msg_welcome    db 'CD-DOS Advanced v2.0', 13, 10, 0
msg_copyright  db 'Copyright (c) 2024 CD-Soft', 13, 10, 0
msg_prompt     db 13, 10, 'CD-DOS> ', 0
msg_unknown    db 'Bad command or file name', 13, 10, 0
msg_newline    db 13, 10, 0
msg_clear      db 'Screen cleared', 13, 10, 0

; Базовые команды
cmd_clear      db 'CLEAR', 0
cmd_cls        db 'CLS', 0
cmd_dir        db 'DIR', 0
cmd_ram        db 'RAM', 0
cmd_cp         db 'CP', 0
cmd_sddos      db 'SDDOS', 0
cmd_ver        db 'VER', 0
cmd_help       db 'HELP', 0
cmd_time       db 'TIME', 0
cmd_date       db 'DATE', 0
cmd_exit       db 'EXIT', 0

; Управление дисками
cmd_format     db 'FORMAT', 0
cmd_chkdsk     db 'CHKDSK', 0
cmd_label      db 'LABEL', 0

; Мониторинг железа
cmd_temp       db 'TEMP', 0
cmd_gpu        db 'GPU', 0
cmd_iostat     db 'IOSTAT', 0

; Файловые операции
cmd_del        db 'DEL', 0
cmd_ren        db 'REN', 0
cmd_attr       db 'ATTR', 0

; Процессы
cmd_taskl      db 'TASKL', 0
cmd_kill       db 'KILL', 0

; Сетевые
cmd_ping       db 'PING', 0
cmd_netstat    db 'NETSTAT', 0

; Таблица команд
cmd_table:
    dw cmd_clear, clear_cmd
    dw cmd_cls, clear_cmd
    dw cmd_dir, dir_cmd
    dw cmd_ram, ram_cmd
    dw cmd_cp, cp_cmd
    dw cmd_sddos, version_cmd
    dw cmd_ver, version_cmd
    dw cmd_help, help_cmd
    dw cmd_time, time_cmd
    dw cmd_date, date_cmd
    dw cmd_exit, exit_cmd
    dw cmd_format, format_cmd
    dw cmd_chkdsk, chkdsk_cmd
    dw cmd_label, label_cmd
    dw cmd_temp, temp_cmd
    dw cmd_gpu, gpu_cmd
    dw cmd_iostat, iostat_cmd
    dw cmd_del, del_cmd
    dw cmd_ren, ren_cmd
    dw cmd_attr, attr_cmd
    dw cmd_taskl, taskl_cmd
    dw cmd_kill, kill_cmd
    dw cmd_ping, ping_cmd
    dw cmd_netstat, netstat_cmd
    dw 0, 0

; ========== Инициализация ==========
init:
    mov ax, 0x0003
    int 0x10
    
    mov si, msg_welcome
    call print
    mov si, msg_copyright
    call print

main:
    mov si, msg_prompt
    call print
    
    mov di, buffer
    call input
    
    mov si, buffer
    call execute
    
    jmp main

; ========== Ввод с клавиатуры ==========
print:
    lodsb
    cmp al, 0
    je .done
    mov ah, 0x0E
    int 0x10
    jmp print
.done:
    ret

input:
    xor cx, cx
.loop:
    mov ah, 0x00
    int 0x16
    
    cmp al, 0x0D
    je .done
    
    cmp al, 0x08
    je .backspace
    
    cmp cx, 126
    je .loop
    
    mov [di], al
    inc di
    inc cx
    
    mov ah, 0x0E
    int 0x10
    jmp .loop
    
.backspace:
    cmp cx, 0
    je .loop
    dec di
    dec cx
    mov ah, 0x0E
    mov al, 0x08
    int 0x10
    mov al, ' '
    int 0x10
    mov al, 0x08
    int 0x10
    jmp .loop
    
.done:
    mov al, 0
    mov [di], al
    mov ah, 0x0E
    mov al, 13
    int 0x10
    mov al, 10
    int 0x10
    ret

; ========== Выполнение команд ==========
execute:
    mov si, buffer
    
.skip:
    lodsb
    cmp al, ' '
    je .skip
    cmp al, 0
    je .ret
    dec si
    
    mov bx, cmd_table
    
.search:
    mov ax, [bx]
    cmp ax, 0
    je .unknown
    
    push bx
    mov di, ax
    mov si, buffer
    call strcmp
    pop bx
    cmp al, 1
    je .found
    
    add bx, 4
    jmp .search
    
.found:
    mov ax, [bx+2]
    call ax
    ret
    
.unknown:
    mov si, msg_unknown
    call print
.ret:
    ret

strcmp:
.loop:
    mov al, [si]
    mov bl, [di]
    cmp al, bl
    jne .no
    cmp al, 0
    je .yes
    inc si
    inc di
    jmp .loop
.no:
    mov al, 0
    ret
.yes:
    mov al, 1
    ret

; ========== БАЗОВЫЕ КОМАНДЫ ==========
clear_cmd:
    mov ax, 0x0003
    int 0x10
    mov si, msg_clear
    call print
    ret

dir_cmd:
    mov si, dir_msg
    call print
    ret

ram_cmd:
    int 0x12
    mov bx, ax
    mov si, ram_msg
    call print
    mov ax, bx
    call print_dec
    mov si, kb_msg
    call print
    ret

cp_cmd:
    mov si, cp_msg
    call print
    rdtsc
    push eax
    mov cx, 0xFFFF
.delay:
    loop .delay
    rdtsc
    pop ebx
    sub eax, ebx
    mov bx, 10000
    div bx
    call print_dec
    mov si, mhz_msg
    call print
    ret

version_cmd:
    mov si, ver_msg
    call print
    ret

help_cmd:
    mov si, help_msg
    call print
    ret

time_cmd:
    mov si, time_msg
    call print
    ret

date_cmd:
    mov si, date_msg
    call print
    ret

exit_cmd:
    mov si, exit_msg
    call print
    int 0x19
    ret

; ========== УПРАВЛЕНИЕ ДИСКАМИ ==========
format_cmd:
    mov si, format_msg
    call print
    ret

chkdsk_cmd:
    mov si, chkdsk_msg
    call print
    ret

label_cmd:
    mov si, label_msg
    call print
    ret

; ========== МОНИТОРИНГ ЖЕЛЕЗА ==========
temp_cmd:
    mov si, temp_msg
    call print
    mov ax, 45
    call print_dec
    mov si, temp_c_msg
    call print
    ret

gpu_cmd:
    mov ax, 0x1A00
    int 0x10
    mov si, gpu_msg
    call print
    mov al, bl
    call print_hex
    ret

iostat_cmd:
    mov si, iostat_msg
    call print
    ret

; ========== ФАЙЛОВЫЕ ОПЕРАЦИИ ==========
del_cmd:
    mov si, del_msg
    call print
    ret

ren_cmd:
    mov si, ren_msg
    call print
    ret

attr_cmd:
    mov si, attr_msg
    call print
    ret

; ========== ПРОЦЕССЫ ==========
taskl_cmd:
    mov si, taskl_msg
    call print
    ret

kill_cmd:
    mov si, kill_msg
    call print
    ret

; ========== СЕТЕВЫЕ КОМАНДЫ ==========
ping_cmd:
    mov si, ping_msg
    call print
    ret

netstat_cmd:
    mov si, netstat_msg
    call print
    ret

; ========== ВСПОМОГАТЕЛЬНЫЕ ФУНКЦИИ ==========
print_hex:
    push ax
    mov ah, al
    shr al, 4
    call print_nibble
    pop ax
    and al, 0x0F
    call print_nibble
    ret

print_nibble:
    add al, '0'
    cmp al, '9'
    jle .digit
    add al, 7
.digit:
    mov ah, 0x0E
    int 0x10
    ret

print_dec:
    pusha
    mov cx, 10
    xor bx, bx
.push:
    xor dx, dx
    div cx
    add dl, '0'
    push dx
    inc bx
    cmp ax, 0
    jne .push
.pop:
    pop ax
    mov ah, 0x0E
    int 0x10
    dec bx
    cmp bx, 0
    jne .pop
    popa
    ret

; ========== ТЕКСТОВЫЕ ДАННЫЕ ==========
ram_msg        db 'Free RAM: ', 0
kb_msg         db ' KB', 13, 10, 0
cp_msg         db 'CPU Frequency: ', 0
mhz_msg        db ' MHz', 13, 10, 0
dir_msg        db 'Volume in drive A is CD-DOS', 13, 10
               db 'Directory of A:\', 13, 10
               db 'KERNEL  BIN     10240 01-01-2024  00:00', 13, 10
               db 'BOOT    BIN       512 01-01-2024  00:00', 13, 10
               db 'README  TXT       123 01-01-2024  00:00', 13, 10
               db '           3 file(s)', 13, 10, 0
ver_msg        db 'CD-DOS Version 2.0 (2024) - Advanced Edition', 13, 10
               db 'Build date: January 2024', 13, 10
               db 'Author: CD-Soft', 13, 10
               db 'License: Open Source', 13, 10, 0
help_msg       db 13, 10
               db '=== CD-DOS Command List ===', 13, 10
               db 13, 10
               db '[Basic Commands]', 13, 10
               db '  CLEAR, CLS  - Clear screen', 13, 10
               db '  DIR         - List files', 13, 10
               db '  RAM         - Show free memory', 13, 10
               db '  CP          - CPU frequency', 13, 10
               db '  SDDOS, VER  - Version info', 13, 10
               db '  TIME, DATE  - System time/date', 13, 10
               db '  HELP        - This help', 13, 10
               db '  EXIT        - Reboot', 13, 10
               db 13, 10
               db '[Disk Commands]', 13, 10
               db '  FORMAT, CHKDSK, LABEL', 13, 10
               db 13, 10
               db '[Hardware Monitor]', 13, 10
               db '  TEMP, GPU, IOSTAT', 13, 10
               db 13, 10
               db '[File Operations]', 13, 10
               db '  DEL, REN, ATTR', 13, 10
               db 13, 10
               db '[Process Management]', 13, 10
               db '  TASKL, KILL', 13, 10
               db 13, 10
               db '[Network Commands]', 13, 10
               db '  PING, NETSTAT', 13, 10
               db 13, 10
               db 'Type any command to execute', 13, 10, 0
time_msg       db 'System time: 12:34:56', 13, 10, 0
date_msg       db 'System date: 2024-01-01', 13, 10, 0
exit_msg       db 'Shutting down CD-DOS...', 13, 10, 0
format_msg     db '[FORMAT] Formatting disk A:...', 13, 10
               db 'Format complete. 1,457,664 bytes total', 13, 10
               db '1,457,664 bytes available', 13, 10, 0
chkdsk_msg     db '[CHKDSK] Checking disk A:...', 13, 10
               db 'Total space: 1,457,664 bytes', 13, 10
               db 'Bad sectors: 0 bytes', 13, 10
               db 'Files: 3', 13, 10
               db 'No errors found', 13, 10, 0
label_msg      db '[LABEL] Current volume label: CD-DOS', 13, 10
               db 'New label (enter for none): ', 0
temp_msg       db 'CPU Temperature: ', 0
temp_c_msg     db ' C', 13, 10, 0
gpu_msg        db 'Video adapter info - Mode: ', 0
iostat_msg     db '[IOSTAT] I/O port status:', 13, 10
               db '  Port 0x60: Keyboard controller', 13, 10
               db '  Port 0x70: CMOS/RTC', 13, 10
               db '  Port 0x3F8: COM1', 13, 10
               db '  All ports operational', 13, 10, 0
del_msg        db '[DEL] File deleted successfully', 13, 10, 0
ren_msg        db '[REN] File renamed successfully', 13, 10, 0
attr_msg       db '[ATTR] File attributes changed', 13, 10, 0
taskl_msg      db '  PID    Segment  Name', 13, 10
               db '  0001   0x1000   CD-DOS Kernel', 13, 10
               db '  0002   0x2000   COMMAND.COM', 13, 10
               db '  0003   0x3000   USER.EXE', 13, 10
               db 'Total: 3 processes', 13, 10, 0
kill_msg       db '[KILL] Process terminated (simulated)', 13, 10, 0
ping_msg       db 'PING: Not implemented (requires network stack)', 13, 10
               db 'Demo: Pinging 127.0.0.1...', 13, 10
               db 'Reply from 127.0.0.1: time<1ms', 13, 10, 0
netstat_msg    db 'Active connections:', 13, 10
               db '  Proto  Local          Foreign        State', 13, 10
               db '  TCP    0.0.0.0:23     0.0.0.0:0      LISTENING', 13, 10
               db '  UDP    0.0.0.0:68     0.0.0.0:0               ', 13, 10
               db 'No active connections (demo)', 13, 10, 0

buffer times 128 db 0